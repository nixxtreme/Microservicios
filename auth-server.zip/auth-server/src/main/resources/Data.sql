INSERT INTO user_info (username, password)
VALUES ('default', '$2a$10$H6zpX00a3pZ3Yprw7Aj7jOSwkwPNdI0TLf2hndxWtt8p5FsIi.qzG');
