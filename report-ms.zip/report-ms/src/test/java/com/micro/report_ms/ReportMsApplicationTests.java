package com.micro.report_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
