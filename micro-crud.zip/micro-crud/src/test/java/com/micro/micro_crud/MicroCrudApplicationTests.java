package com.micro.micro_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
