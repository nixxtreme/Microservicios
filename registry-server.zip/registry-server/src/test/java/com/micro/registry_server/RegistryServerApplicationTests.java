package com.micro.registry_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
